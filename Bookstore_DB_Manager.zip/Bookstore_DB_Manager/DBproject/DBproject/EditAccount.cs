﻿using DBproject.DatabaseProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Data;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace DBproject
{
    public partial class EditAccount : Form
    {
        public EditAccount()
        {
            InitializeComponent();
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            label2.Text = "Wellcome " + Login.name;
            NameTxtBox.Text = Login.name;
            EmailTxtBox.Text = Login.email;
            PasswordTxtBox.Text = Login.password;
            CountryTxtBox.Text = Login.conutry;

        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            string newname = NameTxtBox.Text;
            string newemail = EmailTxtBox.Text;
            string newpassword = PasswordTxtBox.Text;
            string newcountry = CountryTxtBox.Text;
            DataTable dt = new DataTable(); 
            DBAccess dbacc = new DBAccess();
       //     string query = "Select * from [User] where Password = '" + newpassword + "' or Email = '" + newemail  + "' or Name= '" + newname + "'";
        //    dbacc.readDatathroughAdapter(query, dt);
           
            if (newname.Equals("")) {
                MessageBox.Show("Enter your new name");
            }
           else if (newemail.Equals("")) {
                MessageBox.Show("Enter your new email");
            }
           else if (newcountry.Equals("")) {
           
                MessageBox.Show("Enter your new country");
            }
           else if (newpassword.Equals("")) {
          
                MessageBox.Show("Enter your new password");
            }
            else
            {
                string id = Login.id;
                bool flg = Login.flg;
                string query2 = "update [User] set Email = '" + @newemail +  "', Country='" + @newcountry +"' , Password = '" + @newpassword +"' , Name ='" + @newname + "' where Userid= '" + @id +"'";
                SqlCommand cmd = new SqlCommand(query2);
               // SqlCommand insert = new SqlCommand("insert into [User] (Userid,Name , Email , Password , Country ,is_Admin) values( @id ,@userName , @email, @password, @country ,@flg )");
                cmd.Parameters.AddWithValue("@userName", @newname);
                cmd.Parameters.AddWithValue("@email", @newemail);
                cmd.Parameters.AddWithValue("@password", @newpassword);
                cmd.Parameters.AddWithValue("@country", @newcountry);
                int row1 = dbacc.executeQuery(cmd);
                if (row1 == 1)
                {
                    MessageBox.Show("Updates Done !");
                    this.Hide();
                    Login l = new Login();
                    l.Show();
                }
            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            DBAccess dbacc = new DBAccess();
            DialogResult dia = MessageBox.Show("Are you sure?", "Delete Account", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dia == DialogResult.Yes)
            {
                string query = "delete from [User] where Userid ='" + Login.id + "'";
                SqlCommand cmd = new SqlCommand(query);
                int row1 = dbacc.executeQuery(cmd);
                if (row1 == 1)
                {
                    MessageBox.Show("Account Deleted!");
                    this.Hide();
                    Login l = new Login();
                    l.Show();
                }
            }
        }

        private void Skip_Click(object sender, EventArgs e)
        {
            
                this.Hide();
                homeadmin  h = new homeadmin();
                h.Show();
             
        }

        
    }
}
