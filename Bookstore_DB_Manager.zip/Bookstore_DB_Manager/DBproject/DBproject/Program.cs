﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace DBproject
{
    internal class Program
    {
        static void Main(string[] args)
        {
             Login l = new Login();
             Application.Run(l);
           // homeadmin l = new homeadmin();
          //  Application.Run(l);
         // Report report = new Report();
        // Application.Run(report);
       //  borrow borrow = new borrow();
         //   Application.Run(borrow);
        }
    }
}
