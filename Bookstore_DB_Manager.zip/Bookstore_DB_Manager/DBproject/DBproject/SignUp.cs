﻿using DBproject.DatabaseProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace DBproject
{
    public partial class SignUp : Form
    {
        DBAccess DBacc = new DBAccess(); 
        public SignUp()
        {
            InitializeComponent();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string userName = NameTxtBox.Text;
            string password = PasswordTxtBox.Text;
            string email = EmailTxtBox.Text;
            string country = countryTxtBox.Text;
            string id = idbox.Text;
            bool isAdmin = IsAdmin.Checked;
            if (id.Equals(""))
            {
                MessageBox.Show("you did not enter your Student id");
            }
           else if (userName.Equals(""))
            {
                MessageBox.Show("Please Entry Your name");
            }
           else if (password.Equals(""))
            {
                MessageBox.Show("Please Entry Your password");
            }
           else if (email.Equals(""))
            {
                MessageBox.Show("Please Entry Your email");
            }
            else
            {
                SqlCommand insert = new SqlCommand("insert into [User] (Userid ,Name , Email , Password , Country , is_Admin) values(@id, @userName , @email, @password, @country , @isAdmin)");
                insert.Parameters.AddWithValue("@userName",userName);
                insert.Parameters.AddWithValue("@email",email);
                insert.Parameters.AddWithValue("@password",password);
                insert.Parameters.AddWithValue("@country",country);
                insert.Parameters.AddWithValue("@id", id);
                insert.Parameters.AddWithValue("@isAdmin", isAdmin);
                int row1 =  DBacc.executeQuery(insert);    
               if (row1 == 1)
                {
                    MessageBox.Show("Account Created Successfully!");
                    this.Hide();
                    Login login = new Login();  
                    login.Show();
                }
                else
                {
                    MessageBox.Show("Error Occurred");
                }
            }
             
        }


    }
}
