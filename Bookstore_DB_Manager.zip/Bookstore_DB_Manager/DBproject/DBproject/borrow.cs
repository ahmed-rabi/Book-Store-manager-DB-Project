﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using DBproject.DatabaseProject;

namespace DBproject
{
    public partial class borrow : Form
    {
        
        public borrow()
        {
            InitializeComponent();
        }
        private void loaddata()
        {
            DBAccess DBacc = new DBAccess();
            string q = "select BookName , Publisher.[Name] , Author.[Name] , book.ISBN , PublicationYear , Category ,Birthday , construction_date , count(*) as 'Number of borrowed copies' from reviews join book on ISBN = Bookid join [User] on reviews.Userid = [User].Userid join Publisher on book.PublisherID = Publisher.PublisherID join book_Author on book.ISBN = book_Author.isbn join Author on Author.AuthorID = book_Author.Authorid  group by BookName , PublicationYear , Category, book.ISBN ,Birthday , construction_date, Publisher.[Name] , Author.[Name]";
            DataTable dt3 = new DataTable();
            DBacc.readDatathroughAdapter(q, dt3);
            dataGridView1.DataSource = dt3;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
            BKName.Text = row.Cells["BookName"].Value.ToString();
            dateTimePicker1.Text = row.Cells["Birthday"].Value.ToString();
            dateTimePicker2.Text = row.Cells["construction_date"].Value.ToString();
            Year.Text = row.Cells["PublicationYear"].Value.ToString();
            jspntxt.Text = row.Cells["ISBN"].Value.ToString();
           Authorname.Text = row.Cells["Name1"].Value.ToString();
            pubname.Text = row.Cells["Name"].Value.ToString();
            Catgtxt.Text = row.Cells["Category"].Value.ToString();
            textBox1.Text = row.Cells["Number of borrowed copies"].Value.ToString();
           //  authorid = int.Parse(row.Cells["AuthorID1"].Value.ToString());
           // publisherid = int.Parse(row.Cells["PublisherID1"].Value.ToString());
           // book = jspntxt.Text;
           // textBox1.Text = row.Cells["quantity"].Value.ToString();
           // comboBox1.Text = (row.Cells["available"].Value.Equals(true)) ? "YES" : "NO";
           // comboBox2.Text = row.Cells["quality"].Value.ToString();
        }

        private void borrow_Load(object sender, EventArgs e)
        {
            loaddata();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditAccount editAccount = new EditAccount();
            editAccount.Show();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeadmin h = new homeadmin();
            h.Show();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report r = new Report();
            r.Show();
        }
        bool open = false;
        private void timer1_Tick(object sender, EventArgs e)
        {
        
                if (open)
                {

                    if (panel3.Width <= 60)
                    {
                        open = false;
                        timer1.Stop();
                    }
                    panel3.Width -= 10;
                }
                else
                {

                    if (panel3.Width >= 210)
                    {
                        open = true;
                        timer1.Stop();
                    }
                    panel3.Width += 10;
                }
             
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
