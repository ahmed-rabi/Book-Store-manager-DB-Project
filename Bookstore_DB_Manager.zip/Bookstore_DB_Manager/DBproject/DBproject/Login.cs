﻿using DBproject.DatabaseProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Net;

namespace DBproject
{
    public partial class Login : Form
    {
        public static string id, name, password, email, conutry;
        public static bool flg;

        private void signUpLaple_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            SignUp s = new SignUp();
            s.Show();
        }

        private void reset_Click(object sender, EventArgs e)
        {
            EmailTxtBox.Text = "";
            PasswordTxtBox.Text = "";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                PasswordTxtBox.UseSystemPasswordChar = false;
            }
            else
            {
                PasswordTxtBox.UseSystemPasswordChar = true ;

            }
        }

        

        DBAccess dbacc = new DBAccess();
        DataTable dt = new DataTable();
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string Email = EmailTxtBox.Text;
            string Password = PasswordTxtBox.Text;
            if (string.IsNullOrEmpty(Email) )
            {
                MessageBox.Show("enter Email");
            }
            else if (string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("enter Password");
            }
            else
            {
                string query = "Select * from [User] where Email = '" + Email + "' and Password = '" + Password +"'";
                dbacc.readDatathroughAdapter(query, dt);
                if (dt.Rows.Count == 1)
                {
                    id = dt.Rows[0]["Userid"].ToString();
                    name = dt.Rows[0]["Name"].ToString();
                    email = dt.Rows[0]["Email"].ToString();
                    conutry = dt.Rows[0]["Country"].ToString();
                    password = dt.Rows[0]["Password"].ToString();
                    flg = dt.Rows[0]["is_Admin"].Equals(true);
                    MessageBox.Show("Your account exists!");
                    dbacc.closeConn();
                    this.Hide();
                    EditAccount h = new EditAccount();
                    h.Show();
                }
            }
        }
    }
}
